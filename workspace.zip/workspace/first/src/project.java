
import java.util.Scanner;
class project 
{
	public static void main(String args[])
	{
		int a,b,c;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter two number");
		a=in.nextInt();
		b=in.nextInt();
		c=a+b;
		System.out.println("sum = "+c);
	}
}





