package test;

public class Class2 {

	public void class2method()
	{
		System.out.println("method2");
		Class1 c1=new Class1();
		c1.method1();
		
	}
}
