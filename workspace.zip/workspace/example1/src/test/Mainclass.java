package test;

public class Mainclass {
	public static void main(String[] args){
		Class2 c2=new Class2();
		c2.class2method();
	}
}
