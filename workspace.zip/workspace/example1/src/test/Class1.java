package test;

public class Class1 {
				public void method1(){
					
					System.out.println("mthod1");
					
				}

				

}
