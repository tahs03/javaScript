
public class Dog extends Animal{
   void sound(){
	   System.out.println("Dogs bark");
	   
   }
public void eat()
{
	 System.out.println("Dogs eat biscuits");
	}
}

