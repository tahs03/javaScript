import java.util.Scanner;


public class shape {
	static double d;
	double e;
	public double calArea(double d,double e)
	{
		double area;
		area=d*e;
		return area;
	}
	public static void disp1()
	{
		System.out.println("static method");
		
		
	}
public static void main(String[] args)
{
	shape rectangle=new shape();
	System.out.println("Please enter the length and breadth");
	Scanner sc=new Scanner(System.in);
	double l=sc.nextDouble();
	double b=sc.nextDouble();
	rectangle.calArea(2.3,4.1);
	System.out.println("area of rectangle = "+rectangle.calArea(l,b));
	
	disp1();
	
}
}