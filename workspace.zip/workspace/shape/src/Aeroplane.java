
public class Aeroplane implements flyingObject,flyingvehicle{
	
	@Override
	public void fly()
	{
		System.out.println("Aeroplane can fly");
	}
	@Override
	public void wings()
	{
		System.out.println("Aeroplane has two wings");
	
	}
	
	
	public static void main(String[] args)
	{
		Aeroplane a1=new Aeroplane();
		a1.fly();
		a1.wings();
		
	}
}
