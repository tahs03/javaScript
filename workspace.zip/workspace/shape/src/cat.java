
public class cat extends Animal {
	
	
	void sound(){
		   System.out.println("the cat mews..");
		   
	   }
	public void eat()
	{
		 System.out.println("cats eat rat");
		}


}
