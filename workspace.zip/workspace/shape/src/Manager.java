
public class Manager {

	
		public void managermethod()
		{
			Employee e1=new Employee();
			e1.id=102;
			System.out.println(e1.id);
			e1.name="tina";
			System.out.println(e1.name);
		}
}
