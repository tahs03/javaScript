
public interface interface2 {
	void method();

	}


