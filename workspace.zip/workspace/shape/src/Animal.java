
abstract public class Animal {

	abstract void sound();
	public void eat(){
		
	}
	public static void main(String []args)
	{
		Dog d1=new Dog();
		d1.eat();
		d1.sound();
		cat c1=new cat();
		c1.sound();
		c1.eat();
		
	}
	
}
	
	
	

