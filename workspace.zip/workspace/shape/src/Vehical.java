
abstract public class Vehical 
{
	abstract void medium();
	
}
