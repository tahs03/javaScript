
public interface flyingObject {
	public void fly();
	
	
}
