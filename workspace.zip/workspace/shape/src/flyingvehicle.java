
public interface flyingvehicle {

	public void wings();
}
