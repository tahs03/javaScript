
public class student {
	
	int stid;
	String name;
	
 public student()
 {
	 System.out.println("first constructor");
	 
 }
 public student(int st,String n)
 {
	 this.stid=st;
	 this.name=n;
	 System.out.println(st);
 }
 public static void main(String[] args)
 {
	// student s1=new student();
	 student s2=new student(11,"ram");
	 System.out.println(s2.stid);
	 System.out.println(s2.name);
	 
	 }
 
}
